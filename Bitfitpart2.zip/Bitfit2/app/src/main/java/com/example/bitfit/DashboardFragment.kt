// DashboardFragment.kt
package com.example.bitfit

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch

class DashboardFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment (R.layout.fragment_dashboard)
        return inflater.inflate(R.layout.fragment_dashboard, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val totalCaloriesTextView = view.findViewById<TextView>(R.id.totalCaloriesTextView)

        // Get the DAO
        val db = AppDatabase.getInstance(requireContext())
        val foodDao = db.foodDao()

        // Observe the database and calculate total calories
        viewLifecycleOwner.lifecycleScope.launch {
            foodDao.getAll().collect { databaseList ->
                var totalCalories = 0
                for (food in databaseList) {
                    // Safe calculation for total calories
                    totalCalories += food.calorieCount?.toIntOrNull() ?: 0
                }
                totalCaloriesTextView.text = "Total Calories: $totalCalories"
            }
        }
    }
}