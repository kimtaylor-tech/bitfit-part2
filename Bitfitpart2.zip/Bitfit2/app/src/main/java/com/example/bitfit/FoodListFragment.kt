// FoodListFragment.kt
package com.example.bitfit

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class FoodListFragment : Fragment() {

    private val foodList = mutableListOf<FoodEntity>()
    private lateinit var foodRecyclerView: RecyclerView
    private lateinit var foodAdapter: FoodAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_food_list, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Set up the RecyclerView
        foodRecyclerView = view.findViewById(R.id.foodRecyclerView)
        foodAdapter = FoodAdapter(foodList)
        foodRecyclerView.adapter = foodAdapter
        foodRecyclerView.layoutManager = LinearLayoutManager(requireContext())

        // Get the DAO
        val db = AppDatabase.getInstance(requireContext())
        val foodDao = db.foodDao()

        // Observe database changes
        viewLifecycleOwner.lifecycleScope.launch {
            foodDao.getAll().collect { databaseList ->
                foodList.clear()
                foodList.addAll(databaseList)
                foodAdapter.notifyDataSetChanged()
            }
        }

        // Launcher for AddFoodActivity
        val addFoodLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                val data: Intent? = result.data
                val foodName = data?.getStringExtra("FOOD_NAME_EXTRA")
                val calorieCount = data?.getStringExtra("CALORIE_COUNT_EXTRA")

                if (foodName != null && calorieCount != null) {
                    val newFood = FoodEntity(foodName = foodName, calorieCount = calorieCount)
                    viewLifecycleOwner.lifecycleScope.launch(Dispatchers.IO) {
                        foodDao.insert(newFood)
                    }
                }
            }
        }

        // Set up the "Add Food" button
        val addFoodButton = view.findViewById<Button>(R.id.addFoodButton)
        addFoodButton.setOnClickListener {
            val intent = Intent(requireContext(), AddFoodActivity::class.java)
            addFoodLauncher.launch(intent)
        }
    }
}
