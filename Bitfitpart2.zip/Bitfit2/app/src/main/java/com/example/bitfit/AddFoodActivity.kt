package com.example.bitfit

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.bitfit.databinding.ActivityAddFoodBinding // Important new import

class AddFoodActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAddFoodBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddFoodBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.saveButton.setOnClickListener {
            val foodName = binding.foodNameEditText.text.toString()
            val calorieCount = binding.calorieCountEditText.text.toString()

            if (foodName.isNotEmpty() && calorieCount.isNotEmpty()) {
                val resultIntent = Intent()
                resultIntent.putExtra("FOOD_NAME_EXTRA", foodName)
                resultIntent.putExtra("CALORIE_COUNT_EXTRA", calorieCount)
                setResult(Activity.RESULT_OK, resultIntent)
                finish()
            }
        }
    }
}