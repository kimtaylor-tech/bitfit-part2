// MainActivity.kt
package com.example.bitfit

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.NavigationUI
import com.google.android.material.bottomnavigation.BottomNavigationView

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Find the Bottom Navigation View
        val bottomNavView = findViewById<BottomNavigationView>(R.id.bottom_nav_view)

        // Find the NavHostFragment (the container for our screens)
        val navHostFragment = supportFragmentManager
            .findFragmentById(R.id.nav_host_fragment) as NavHostFragment

        // Get the NavController
        val navController = navHostFragment.navController

        // Connect the BottomNavigationView to the NavController
        // This makes the buttons switch fragments!
        NavigationUI.setupWithNavController(bottomNavView, navController)
    }
}